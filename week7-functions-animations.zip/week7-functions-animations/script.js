/*
 * Week 7 Assignment - JavaScript Functions & CSS Animations
 * This script demonstrates:
 * - Function scope and variable visibility
 * - Parameters and return values
 * - Higher-order functions
 * - Animation control with JavaScript
 * - Interactive project implementations
 */

// ===========================================
// GLOBAL VARIABLES AND APPLICATION STATE
// ===========================================

// Global scope variables - accessible throughout the application
const appState = {
    currentNumbers: [],
    calculationHistory: [],
    isTimelineRunning: false,
    currentColor: { r: 127, g: 127, b: 127 },
    animationState: 'running'
};

// ===========================================
// PART 1: FUNCTION SCOPE DEMONSTRATION
// ===========================================

// Global variable - accessible everywhere
let globalCounter = 0;
const GLOBAL_CONSTANT = "I'm a global constant";

// Function demonstrating different scopes
function demonstrateScope() {
    // Local variable - only accessible within this function
    const localVar = "I'm local to demonstrateScope function";
    
    // Modifying global variable
    globalCounter++;
    
    // Block scope example within function
    if (true) {
        const blockScopedVar = "I'm block scoped";
        // This variable is only accessible within this if block
    }
    
    return {
        globalConstant: GLOBAL_CONSTANT,
        localVariable: localVar,
        updatedCounter: globalCounter,
        // blockScopedVar would cause an error here - it's out of scope
    };
}

// Function demonstrating block scope with let/const
function demonstrateBlockScope() {
    let functionScoped = "I'm function scoped";
    
    if (true) {
        let blockScoped = "I'm block scoped";
        const alsoBlockScoped = "Me too!";
        functionScoped = "I can be modified in blocks";
        
        // These are accessible here
        console.log(blockScoped, alsoBlockScoped);
    }
    
    // This would cause an error - blockScoped is not accessible here
    // console.log(blockScoped);
    
    return "Block scoped variables are only accessible within their {} blocks";
}

// ===========================================
// PART 2: PARAMETERS & RETURN VALUES
// ===========================================

// Function with default parameters
function greetUser(name = "Guest", greeting = "Hello") {
    // Using template literals for string interpolation
    return `${greeting}, ${name}! Welcome to our application.`;
}

// Function with rest parameters and comprehensive return value
function calculateSum(...numbers) {
    // Input validation
    if (numbers.length === 0) {
        return {
            error: "No numbers provided",
            numbers: [],
            sum: 0,
            count: 0,
            average: 0
        };
    }
    
    let sum = 0;
    let validNumbers = [];
    
    // Filter out non-numbers and calculate sum
    for (let num of numbers) {
        if (typeof num === 'number' && !isNaN(num)) {
            validNumbers.push(num);
            sum += num;
        }
    }
    
    const count = validNumbers.length;
    const average = count > 0 ? sum / count : 0;
    
    // Returning an object with multiple values
    return {
        numbers: validNumbers,
        sum: sum,
        count: count,
        average: average,
        formattedAverage: average.toFixed(2),
        summary: `Sum of ${count} numbers: ${sum} (Average: ${average.toFixed(2)})`
    };
}

// Higher-order function that returns a function
function createMultiplier(factor) {
    // Parameter 'factor' is captured in the closure
    return function(number) {
        return number * factor;
    };
}

// Creating specialized multiplier functions
const double = createMultiplier(2);
const triple = createMultiplier(3);
const quadruple = createMultiplier(4);

// ===========================================
// PART 3: ANIMATION CONTROL FUNCTIONS
// ===========================================

// Function to handle transition box interactions
function handleTransitionBox(action) {
    const box = document.getElementById('transitionBox');
    
    // Remove all transition classes first
    box.classList.remove('grow', 'color', 'rotate');
    
    // Apply the requested transition
    switch(action) {
        case 'grow':
            box.classList.add('grow');
            break;
        case 'color':
            box.classList.add('color');
            break;
        case 'rotate':
            box.classList.add('rotate');
            break;
        case 'reset':
            // Just removing classes is enough to reset
            break;
        default:
            console.warn('Unknown transition action:', action);
    }
}

// Function to control keyframe animations
function controlKeyframeAnimation(animationType) {
    const element = document.getElementById('keyframeElement');
    
    // Remove all animation classes first
    element.classList.remove('bounce', 'pulse', 'slide', 'spin');
    
    if (animationType !== 'stop') {
        // Add the requested animation
        element.classList.add(animationType);
    }
    
    // Additional effects based on animation type
    switch(animationType) {
        case 'bounce':
            element.style.backgroundColor = '#f59e0b'; // Amber
            break;
        case 'pulse':
            element.style.backgroundColor = '#10b981'; // Emerald
            break;
        case 'slide':
            element.style.backgroundColor = '#6366f1'; // Indigo
            break;
        case 'spin':
            element.style.backgroundColor = '#ef4444'; // Red
            break;
        default:
            element.style.backgroundColor = '#6366f1'; // Default indigo
    }
}

// Function to control timeline animation sequence
function startTimelineSequence() {
    if (appState.isTimelineRunning) return;
    
    appState.isTimelineRunning = true;
    const dots = [
        document.getElementById('dot1'),
        document.getElementById('dot2'),
        document.getElementById('dot3'),
        document.getElementById('dot4')
    ];
    
    // Reset all dots first
    dots.forEach(dot => {
        dot.classList.remove('active', 'animate');
    });
    
    // Animate dots in sequence
    dots.forEach((dot, index) => {
        setTimeout(() => {
            dot.classList.add('active', 'animate');
            
            // Remove animation class after animation completes
            setTimeout(() => {
                dot.classList.remove('animate');
            }, 600);
            
            // If this is the last dot, mark sequence as complete
            if (index === dots.length - 1) {
                setTimeout(() => {
                    appState.isTimelineRunning = false;
                }, 1000);
            }
        }, index * 800);
    });
}

function resetTimelineSequence() {
    const dots = [
        document.getElementById('dot1'),
        document.getElementById('dot2'),
        document.getElementById('dot3'),
        document.getElementById('dot4')
    ];
    
    dots.forEach(dot => {
        dot.classList.remove('active', 'animate');
    });
    
    appState.isTimelineRunning = false;
}

// ===========================================
// PART 4: INTERACTIVE PROJECT FUNCTIONS
// ===========================================

// Color Mixer Functions
function updateColorMixer() {
    const red = parseInt(document.getElementById('redSlider').value);
    const green = parseInt(document.getElementById('greenSlider').value);
    const blue = parseInt(document.getElementById('blueSlider').value);
    
    // Update global state
    appState.currentColor = { r: red, g: green, b: blue };
    
    // Update display values
    document.getElementById('redValue').textContent = red;
    document.getElementById('greenValue').textContent = green;
    document.getElementById('blueValue').textContent = blue;
    
    // Update color preview
    const colorPreview = document.getElementById('colorPreview');
    const colorOutput = document.getElementById('colorOutput');
    
    const rgbString = `rgb(${red}, ${green}, ${blue})`;
    colorPreview.style.backgroundColor = rgbString;
    colorOutput.textContent = rgbString;
    
    // Calculate complementary color for text contrast
    const brightness = (red * 299 + green * 587 + blue * 114) / 1000;
    colorOutput.style.color = brightness > 125 ? '#000000' : '#ffffff';
}

// Animation Player Functions
function setupAnimationPlayer() {
    const playerElement = document.getElementById('playerElement');
    const progressFill = document.getElementById('progressFill');
    
    let progress = 0;
    let direction = 1;
    let isPlaying = true;
    
    function updateProgress() {
        if (!isPlaying) return;
        
        progress += direction * 0.5;
        
        if (progress >= 100) {
            progress = 100;
            direction = -1;
        } else if (progress <= 0) {
            progress = 0;
            direction = 1;
        }
        
        progressFill.style.width = `${progress}%`;
        requestAnimationFrame(updateProgress);
    }
    
    // Start the progress animation
    updateProgress();
    
    // Return control functions
    return {
        play: function() {
            isPlaying = true;
            playerElement.style.animationPlayState = 'running';
            updateProgress();
        },
        pause: function() {
            isPlaying = false;
            playerElement.style.animationPlayState = 'paused';
        },
        reverse: function() {
            direction = -direction;
        },
        reset: function() {
            progress = 0;
            direction = 1;
            progressFill.style.width = '0%';
            playerElement.style.animation = 'none';
            setTimeout(() => {
                playerElement.style.animation = 'player-move 3s ease-in-out infinite';
            }, 10);
        }
    };
}

// Calculator Functions
function performCalculation(operation) {
    const inputA = parseFloat(document.getElementById('calcInputA').value);
    const inputB = parseFloat(document.getElementById('calcInputB').value);
    
    // Input validation
    if (isNaN(inputA) || isNaN(inputB)) {
        return {
            success: false,
            result: "Please enter valid numbers",
            operation: operation
        };
    }
    
    let result;
    let expression;
    
    switch(operation) {
        case 'add':
            result = inputA + inputB;
            expression = `${inputA} + ${inputB}`;
            break;
        case 'subtract':
            result = inputA - inputB;
            expression = `${inputA} - ${inputB}`;
            break;
        case 'multiply':
            result = inputA * inputB;
            expression = `${inputA} × ${inputB}`;
            break;
        case 'divide':
            if (inputB === 0) {
                return {
                    success: false,
                    result: "Cannot divide by zero",
                    operation: operation
                };
            }
            result = inputA / inputB;
            expression = `${inputA} ÷ ${inputB}`;
            break;
        case 'power':
            result = Math.pow(inputA, inputB);
            expression = `${inputA}^${inputB}`;
            break;
        default:
            return {
                success: false,
                result: "Unknown operation",
                operation: operation
            };
    }
    
    const calculation = {
        expression: expression,
        result: result,
        operation: operation,
        timestamp: new Date().toLocaleTimeString()
    };
    
    // Add to history
    appState.calculationHistory.unshift(calculation);
    
    return {
        success: true,
        calculation: calculation,
        formattedResult: `${expression} = ${result}`
    };
}

function updateCalculationHistory() {
    const historyElement = document.getElementById('calcHistory');
    historyElement.innerHTML = '';
    
    // Show only last 5 calculations
    const recentCalculations = appState.calculationHistory.slice(0, 5);
    
    recentCalculations.forEach(calc => {
        const historyItem = document.createElement('div');
        historyItem.className = 'calc-history-item';
        historyItem.textContent = `${calc.expression} = ${calc.result} (${calc.timestamp})`;
        historyElement.appendChild(historyItem);
    });
}

// ===========================================
// UTILITY FUNCTIONS
// ===========================================

// Function to display output with formatting
function displayOutput(elementId, content, isError = false) {
    const outputElement = document.getElementById(elementId);
    
    if (typeof content === 'object') {
        // Format objects as JSON strings
        content = JSON.stringify(content, null, 2);
    }
    
    outputElement.textContent = content;
    outputElement.style.borderColor = isError ? '#ef4444' : '#10b981';
    outputElement.style.backgroundColor = isError ? '#fef2f2' : '#f0fdf4';
}

// Function to show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : type === 'success' ? '#10b981' : '#6366f1'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

// ===========================================
// EVENT LISTENER SETUP
// ===========================================

function initializeEventListeners() {
    console.log("Initializing Week 7 event listeners...");
    
    // Hero button animation
    document.getElementById('heroButton').addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 150);
        
        document.getElementById('scope-section').scrollIntoView({ 
            behavior: 'smooth' 
        });
    });
    
    // Scope demonstration buttons
    document.getElementById('scopeDemoBtn').addEventListener('click', function() {
        const result = demonstrateScope();
        displayOutput('scopeOutput', result);
    });
    
    document.getElementById('blockScopeBtn').addEventListener('click', function() {
        const result = demonstrateBlockScope();
        displayOutput('blockScopeOutput', result);
    });
    
    // Parameters demonstration
    document.getElementById('greetBtn').addEventListener('click', function() {
        const name = document.getElementById('userName').value;
        const greeting = document.getElementById('userGreeting').value;
        
        const result = greetUser(name || undefined, greeting || undefined);
        displayOutput('greetOutput', result);
    });
    
    // Number calculations
    document.getElementById('addNumberBtn').addEventListener('click', function() {
        const input = document.getElementById('numberInput');
        const number = parseFloat(input.value);
        
        if (!isNaN(number)) {
            appState.currentNumbers.push(number);
            input.value = '';
            
            const numberList = document.getElementById('numberList');
            numberList.textContent = `Numbers: [${appState.currentNumbers.join(', ')}]`;
        }
    });
    
    document.getElementById('calculateBtn').addEventListener('click', function() {
        const result = calculateSum(...appState.currentNumbers);
        displayOutput('calculationOutput', result.summary);
    });
    
    // Multiplier buttons
    document.getElementById('doubleBtn').addEventListener('click', function() {
        const input = parseFloat(document.getElementById('multiplierInput').value);
        if (!isNaN(input)) {
            const result = double(input);
            displayOutput('multiplierOutput', `${input} × 2 = ${result}`);
        }
    });
    
    document.getElementById('tripleBtn').addEventListener('click', function() {
        const input = parseFloat(document.getElementById('multiplierInput').value);
        if (!isNaN(input)) {
            const result = triple(input);
            displayOutput('multiplierOutput', `${input} × 3 = ${result}`);
        }
    });
    
    // Transition controls
    document.querySelectorAll('.transition-controls .control-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            handleTransitionBox(action);
        });
    });
    
    // Animation controls
    document.querySelectorAll('.animation-controls .control-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const animation = this.getAttribute('data-animation');
            controlKeyframeAnimation(animation);
        });
    });
    
    // Timeline controls
    document.getElementById('startTimeline').addEventListener('click', startTimelineSequence);
    document.getElementById('resetTimeline').addEventListener('click', resetTimelineSequence);
    
    // Color mixer
    document.querySelectorAll('.color-sliders input[type="range"]').forEach(slider => {
        slider.addEventListener('input', updateColorMixer);
    });
    
    // Animation player
    let playerControls;
    document.addEventListener('DOMContentLoaded', function() {
        playerControls = setupAnimationPlayer();
    });
    
    document.getElementById('playBtn').addEventListener('click', () => playerControls.play());
    document.getElementById('pauseBtn').addEventListener('click', () => playerControls.pause());
    document.getElementById('reverseBtn').addEventListener('click', () => playerControls.reverse());
    document.getElementById('resetPlayerBtn').addEventListener('click', () => playerControls.reset());
    
    // Calculator
    document.querySelectorAll('.calc-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const operation = this.getAttribute('data-operation');
            const result = performCalculation(operation);
            
            if (result.success) {
                document.getElementById('calcOutput').textContent = result.formattedResult;
                updateCalculationHistory();
            } else {
                document.getElementById('calcOutput').textContent = result.result;
                document.getElementById('calcOutput').style.color = '#ef4444';
            }
        });
    });
}

// ===========================================
// INITIALIZATION
// ===========================================

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("Week 7 Assignment - Functions & Animations Initialized");
    
    initializeEventListeners();
    updateColorMixer(); // Initialize color mixer
    
    // Add some sample calculations to history
    appState.calculationHistory = [
        { expression: "10 + 5", result: 15, operation: "add", timestamp: "Sample" },
        { expression: "20 ÷ 4", result: 5, operation: "divide", timestamp: "Sample" }
    ];
    updateCalculationHistory();
    
    showNotification('Week 7 Assignment Loaded Successfully!', 'success');
});

// Make some functions globally available for HTML event handlers
window.handleTransitionBox = handleTransitionBox;
window.controlKeyframeAnimation = controlKeyframeAnimation;